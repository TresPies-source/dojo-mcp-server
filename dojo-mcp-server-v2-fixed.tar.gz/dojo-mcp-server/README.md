# Dojo Genesis MCP Server

![Dojo Genesis Logo](https://raw.githubusercontent.com/TresPies-source/dojo-genesis/main/frontend/public/Dojo%20Genesis%20Logo.png)

**The Model Context Protocol server for Dojo Genesis** - Spread the name and techniques of Dojo through any MCP-compatible AI agent.

## What is This?

The Dojo Genesis MCP Server exposes the core principles, patterns, and wisdom of the Dojo ecosystem through the Model Context Protocol (MCP). It provides a rich set of tools, prompts, and resources that enable any AI agent to think with AI in a more mindful, effective, and human-centric way.

## Core Capabilities

### 🛠️ Tools

- **`dojo.reflect`** - The core Dojo thinking partner. Applies one of the four Dojo modes (Mirror, Scout, Gardener, Implementation) to a given situation and set of perspectives.
- **`dojo.search_wisdom`** - Performs a semantic search on the entire Dojo wisdom base, including all seed patches, documentation, and principles.
- **`dojo.get_seed`** - Retrieves a specific Dojo Seed Patch by name.
- **`dojo.apply_seed`** - Applies a Dojo Seed Patch to a given situation, providing guidance and a checklist.
- **`dojo.list_seeds`** - Lists all available Dojo Seed Patches with their descriptions.
- **`dojo.get_principles`** - Retrieves the three core Dojo principles: Beginner's Mind, Self-Definition, and Understanding is Love.

### 📝 Prompts

The 10 Dojo Seed Patches are exposed as MCP prompts:

1. **`dojo.seed.three_tiered_governance`** - A three-tiered governance framework for AI systems
2. **`dojo.seed.harness_trace`** - Complete traceability for agent reasoning
3. **`dojo.seed.context_iceberg`** - 4-tier context management system
4. **`dojo.seed.agent_connect`** - Routing-first agent architecture
5. **`dojo.seed.go_live_bundles`** - Lightweight deployment packages
6. **`dojo.seed.cost_guard`** - Budget for the full context iceberg
7. **`dojo.seed.safety_switch`** - User control and approval workflows
8. **`dojo.seed.implicit_perspective_extraction`** - Extract perspectives from queries
9. **`dojo.seed.mode_based_complexity_gating`** - Cost-aware model routing
10. **`dojo.seed.shared_infrastructure`** - Build once, reuse everywhere

### 📚 Resources

- **`dojo://wisdom_synthesis`** - The complete synthesis of Dojo wisdom
- **`dojo://agent_protocol`** - The Dojo Agent Protocol v1.0 documentation
- **`dojo://four_modes`** - The Four Modes of Dojo
- **`dojo://planning_with_files`** - The planning-with-files pattern

## Installation

### Using Docker (Recommended)

The server is distributed as a Docker container for easy installation and management.

```bash
docker pull ghcr.io/trespies-source/dojo-mcp-server:latest
```

### Configuration for Claude Desktop

Add the following to your `claude_desktop_config.json`:

**macOS/Linux:**
```json
{
  "mcpServers": {
    "dojo-genesis": {
      "command": "docker",
      "args": [
        "run",
        "-i",
        "--rm",
        "ghcr.io/trespies-source/dojo-mcp-server:latest"
      ]
    }
  }
}
```

**Windows:**
```json
{
  "mcpServers": {
    "dojo-genesis": {
      "command": "docker",
      "args": [
        "run",
        "-i",
        "--rm",
        "ghcr.io/trespies-source/dojo-mcp-server:latest"
      ]
    }
  }
}
```

### Configuration for VS Code

Add the following to your VS Code MCP settings:

```json
{
  "servers": {
    "dojo-genesis": {
      "type": "stdio",
      "command": "docker",
      "args": [
        "run",
        "-i",
        "--rm",
        "ghcr.io/trespies-source/dojo-mcp-server:latest"
      ]
    }
  }
}
```

## Usage Examples

### Reflecting on a Situation

```
Use the dojo.reflect tool with:
- situation: "Should I refactor this codebase?"
- perspectives: ["maintainability", "time/cost", "risk", "team impact"]
- mode: "scout"
```

The server will provide a Scout-mode reflection, offering 2-4 routes with tradeoffs and a recommended smallest test step.

### Searching the Wisdom Base

```
Use the dojo.search_wisdom tool with:
- query: "context management"
```

The server will return relevant seeds, resources, and principles related to context management.

### Applying a Seed Patch

```
Use the dojo.apply_seed tool with:
- seed_name: "three_tiered_governance"
- situation: "I'm building a multi-agent AI system and need to establish governance"
```

The server will provide guidance on applying the Three-Tiered Governance seed to your specific situation.

## Philosophy

This server is not just a technical artifact; it is a transmission of practice. Every aspect of its design is grounded in the core Dojo philosophy:

- **Beginner's Mind**: The server encourages exploration and fresh perspectives, avoiding rigid, prescriptive tools.
- **Self-Definition**: The tools help users see their own thinking, not impose external frameworks.
- **Understanding is Love**: The server provides deep, non-judgmental understanding of the user's context.

## Building from Source

If you prefer to build from source:

```bash
# Clone the repository
git clone https://github.com/TresPies-source/dojo-mcp-server.git
cd dojo-mcp-server

# Build the Docker image
docker build -t dojo-mcp-server .

# Run the server
docker run -i --rm dojo-mcp-server
```

Or build the Go binary directly:

```bash
# Install dependencies
go mod download

# Build the binary
go build -o server ./cmd/server

# Run the server
./server
```

## Contributing

We welcome contributions! Please see [CONTRIBUTING.md](CONTRIBUTING.md) for guidelines.

## License

MIT License - see [LICENSE](LICENSE) for details.

## Links

- **Dojo Genesis**: [github.com/TresPies-source/dojo-genesis](https://github.com/TresPies-source/dojo-genesis)
- **Model Context Protocol**: [modelcontextprotocol.io](https://modelcontextprotocol.io)
- **Issues**: [github.com/TresPies-source/dojo-mcp-server/issues](https://github.com/TresPies-source/dojo-mcp-server/issues)

---

**Built with ❤️ by the Dojo Genesis community**
